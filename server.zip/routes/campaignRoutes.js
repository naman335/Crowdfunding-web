const express = require("express");
const Joi = require("joi");
const Campaign = require("../models/Campaign");
const { protect, admin } = require("../middleware/authMiddleware");
const { sendEmail } = require("../utils/emailService");
const router = express.Router();
const Razorpay = require("razorpay");
const dotenv = require("dotenv");
const multer = require("multer");
const cloudinary = require("cloudinary").v2;
const { CloudinaryStorage } = require("multer-storage-cloudinary");

dotenv.config();

// Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// Validation schema for campaign creation
const campaignSchema = Joi.object({
  title: Joi.string().required(),
  description: Joi.string().required(),
  goal: Joi.number().positive().required(),
  category: Joi.string().required(),
});

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Configure Multer storage for Cloudinary
const storage = new CloudinaryStorage({
  cloudinary,
  params: {
    folder: "campaigns",
    allowed_formats: ["jpg", "jpeg", "png"],
  },
});
const upload = multer({ storage });

// Create a campaign
router.post("/create", protect, upload.single("image"), async (req, res) => {
  const { error } = campaignSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const { title, description, goal, category } = req.body;
    const imageUrl = req.file ? req.file.path : null;

    const campaign = await Campaign.create({
      title,
      description,
      goal,
      category,
      image: imageUrl,
      creator: req.user.id,
    });

    res.status(201).json(campaign);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
});

// Fund a campaign
router.post("/:id/fund", protect, async (req, res) => {
  try {
    const campaign = await Campaign.findById(req.params.id);

    if (!campaign)
      return res.status(404).json({ message: "Campaign not found" });

    const { amount } = req.body;
    if (!amount || amount <= 0)
      return res.status(400).json({ message: "Invalid amount" });

    // Convert amount to paise (Razorpay works in INR paise)
    const amountInPaise = amount * 100;

    // Create a Razorpay order
    const options = {
      amount: amountInPaise,
      currency: "INR",
      receipt: `rec_${campaign._id.toString().slice(-6)}_${Date.now()
        .toString()
        .slice(-4)}`, // Shorten receipt ID
      payment_capture: 1, // Auto-capture payment
    };

    const order = await razorpay.orders.create(options);

    res.status(200).json({
      success: true,
      orderId: order.id,
      amount: amountInPaise,
      currency: "INR",
      key: process.env.RAZORPAY_KEY_ID, // Send key to frontend
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// verify payment
router.post("/:id/verify-payment", protect, async (req, res) => {
  try {
    const { paymentId } = req.body;
    const campaign = await Campaign.findById(req.params.id);

    if (!campaign) {
      return res.status(404).json({ message: "Campaign not found" });
    }

    // Step 1: Verify payment with Razorpay API
    const paymentDetails = await razorpay.payments.fetch(paymentId);

    // Step 2: Check if the payment is successful
    if (paymentDetails.status !== "captured") {
      return res.status(400).json({ message: "Payment verification failed" });
    }

    // Step 3: Verify if the amount matches the campaign's expected amount
    const { amount } = req.body; // Assuming amount is passed from frontend
    if (amount !== paymentDetails.amount / 100) {
      return res.status(400).json({ message: "Payment amount mismatch" });
    }

    // Step 4: Update the campaign with the payment
    campaign.raisedAmount += amount;
    campaign.backers.push({ user: req.user.id, amount });

    await campaign.save();

    res.status(200).json({ message: "Payment verified and campaign updated" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// GET /api/categories - Fetch unique campaign categories
router.get("/categories", async (req, res) => {
  try {
    const categories = await Campaign.distinct("category"); // Get unique categories
    res.json(categories);
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).json({ error: "Server error while fetching categories" });
  }
});

// Get all campaign for admin
router.get("/admin", protect, admin, async (req, res) => {
  try {
    const campaigns = await Campaign.find()
      .populate("backers.user", "name") // Get supporter names
      .lean();

    const updatedCampaigns = campaigns.map((campaign) => ({
      ...campaign,
      totalSupporters: campaign.backers.length,
      supportersList: campaign.backers.map((backer) => ({
        name: backer.user?.name || "Anonymous",
        amount: backer.amount,
      })),
    }));

    res.status(200).json(updatedCampaigns);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// recent 3 campaign
router.get("/recent-campaigns", async (req, res) => {
  try {
    const campaigns = await Campaign.find({ isApproved: true })
      .populate("backers.user", "name") // Get supporter names
      .sort({ createdAt: -1 }) // Sort campaigns by creation date in descending order
      .limit(3) // Limit to the 3 most recent campaigns
      .lean();

    const updatedCampaigns = campaigns.map((campaign) => ({
      ...campaign,
      totalSupporters: campaign.backers.length,
      supportersList: campaign.backers.map((backer) => ({
        name: backer.user?.name || "Anonymous",
        amount: backer.amount,
      })),
    }));

    res.status(200).json(updatedCampaigns);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// Delete campaign by ID
router.delete("/:id", protect, admin, async (req, res) => {
  try {
    const campaign = await Campaign.findByIdAndDelete(req.params.id);
    if (!campaign) {
      return res.status(404).json({ error: "Campaign not found" });
    }
    return res.json({ message: "Campaign deleted successfully" });
  } catch (error) {
    console.error("Error deleting campaign:", error);
    return res.status(500).json({ error: "Server error" });
  }
});

const getPublicIdFromUrl = (url) => {
  const regex = /\/upload\/v\d+\/(.+?)\./;
  const match = url?.match(regex);
  return match ? match[1] : null;
};
// Update campaign details (title, description, goal, category)
router.patch(
  "/update/:id",
  protect,
  admin,
  upload.single("image"),
  async (req, res) => {
    try {
      const campaign = await Campaign.findById(req.params.id);
      if (!campaign)
        return res.status(404).json({ error: "Campaign not found" });

      const updateData = {
        title: req.body.title || campaign.title,
        description: req.body.description || campaign.description,
        goal: req.body.goal || campaign.goal,
        category: req.body.category || campaign.category,
      };

      if (req.file) {
        // Delete old image if exists
        if (campaign.image) {
          const publicId = getPublicIdFromUrl(campaign.image);
          if (publicId) {
            await cloudinary.uploader.destroy(publicId).catch(console.error);
          }
        }
        updateData.image = req.file.path;
      }

      const updatedCampaign = await Campaign.findByIdAndUpdate(
        req.params.id,
        updateData,
        { new: true }
      );

      res.json(updatedCampaign);
    } catch (error) {
      console.error("Error updating campaign:", error);
      res.status(500).json({ error: "Server error" });
    }
  }
);

// get single campaign
router.get("/:id", async (req, res) => {
  try {
    const campaign = await Campaign.findById(req.params.id)
      .populate("backers.user", "name") // Get supporter names
      .lean();

    if (!campaign) {
      return res.status(404).json({ message: "Campaign not found" });
    }

    // Modify the campaign object directly
    campaign.totalSupporters = campaign?.backers?.length;
    campaign.supportersList = campaign.backers?.map((backer) => ({
      name: backer.user?.name || "Anonymous",
      amount: backer.amount,
    }));

    res.status(200).json(campaign);
  } catch (error) {
    res.status(500).json({ error: "Error fetching campaign" });
  }
});

// Notify backers about milestones
router.post("/:id/milestone", protect, async (req, res) => {
  try {
    const campaign = await Campaign.findById(req.params.id).populate(
      "backers.user",
      "email"
    );
    if (!campaign) {
      return res.status(404).json({ message: "Campaign not found" });
    }

    const { message } = req.body;
    if (!message) {
      return res.status(400).json({ message: "Message is required" });
    }

    const emailPromises = campaign.backers.map(async (backer) => {
      if (backer.user && backer.user.email) {
        return sendEmail(
          backer.user.email,
          "Campaign Milestone Update",
          `Hello, there's an update on the campaign "${campaign.title}": ${message}`
        );
      }
    });

    await Promise.all(emailPromises);
    res.status(200).json({
      message: `Milestone notifications sent to backers of campaign "${campaign.title}"`,
    });
  } catch (error) {
    console.error("Error sending milestone notifications:", error);
    res.status(500).json({ message: error.message });
  }
});

// Get all campaigns with filters
router.get("/", async (req, res) => {
  try {
    const { keyword, category, minGoal, maxGoal } = req.query;

    const query = {
      isApproved: true,
      ...(keyword && { title: { $regex: keyword, $options: "i" } }),
      ...(category && { category: { $in: category.split(",") } }), // Supports multiple categories
      ...(minGoal && { goal: { $gte: Number(minGoal) } }),
      ...(maxGoal && { goal: { $lte: Number(maxGoal) } }),
    };

    const campaigns = await Campaign.find(query)
      .populate("backers.user", "name") // Get supporter names
      .lean();

    const updatedCampaigns = campaigns.map((campaign) => ({
      ...campaign,
      totalSupporters: campaign.backers.length,
      supportersList: campaign.backers.map((backer) => ({
        name: backer.user?.name || "Anonymous",
        amount: backer.amount,
      })),
    }));

    res.status(200).json(updatedCampaigns);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
