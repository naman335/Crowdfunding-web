const express = require("express");
const router = express.Router();
const Contact = require("../models/Contact");
const { protect, admin } = require("../middleware/authMiddleware");
const { create } = require("../models/User");

// 📌 POST /api/contact - Create a new contact message
router.post("/", protect, async (req, res) => {
  try {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const newContact = await Contact.create({ name, email, message });

    res
      .status(201)
      .json({ message: "Message sent successfully!", data: newContact });
  } catch (error) {
    console.error("Error saving contact message:", error);
    res.status(500).json({ error: "Server error while saving message" });
  }
});

// 📌 GET /api/contact - Get all messages (Admin Only)
router.get("/", protect, admin, async (req, res) => {
  try {
    const messages = await Contact.find().sort({ createdAt: -1 }); // Latest messages first
    res.status(200).json(messages);
  } catch (error) {
    console.error("Error fetching messages:", error);
    res.status(500).json({ error: "Server error while fetching messages" });
  }
});

// 📌 DELETE /api/contact/:id - Delete a message
router.delete("/:id", protect, admin, async (req, res) => {
  try {
    const { id } = req.params;
    await Contact.findByIdAndDelete(id);
    res.status(200).json({ message: "Message deleted successfully" });
  } catch (error) {
    console.error("Error deleting message:", error);
    res.status(500).json({ error: "Server error while deleting message" });
  }
});

module.exports = router;
