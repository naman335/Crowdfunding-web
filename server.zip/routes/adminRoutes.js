const express = require("express");
const Campaign = require("../models/Campaign");
const { protect, admin } = require("../middleware/authMiddleware");
const router = express.Router();

// Approve a campaign
router.patch("/campaign/:id/approve", protect, admin, async (req, res) => {
  try {
    const campaign = await Campaign.findById(req.params.id);
    console.log("Campaign to be approved:", campaign);

    if (!campaign)
      return res.status(404).json({ message: "Campaign not found" });

    // if approve then disaprove and if disaprve then aprove
    campaign.isApproved = !campaign.isApproved;
    // campaign.isApproved = true;
    await campaign.save();

    res.status(200).json({ message: "Campaign approved", campaign });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
});

// Get platform analytics
router.get("/analytics", protect, admin, async (req, res) => {
  try {
    const totalCampaigns = await Campaign.countDocuments();
    const totalFundsRaised = await Campaign.aggregate([
      { $group: { _id: null, total: { $sum: "$raisedAmount" } } },
    ]);
    const analytics = {
      totalCampaigns,
      totalFundsRaised: totalFundsRaised[0]?.total || 0,
    };

    res.status(200).json(analytics);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
