const nodemailer = require("nodemailer");
require("dotenv").config(); // Ensure dotenv is loaded

// Configure the transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com", // Default to Gmail SMTP
  port: process.env.SMTP_PORT || 587, // Use 587 for TLS, 465 for SSL
  secure: process.env.SMTP_PORT == 465, // true for SSL, false for TLS
  auth: {
    user: process.env.SMTP_MAIL, // Your email
    pass: process.env.SMTP_PASSWORD, // App password
  },
});

// Function to send emails
const sendEmail = async (to, subject, text) => {
  try {
    const mailOptions = {
      from: process.env.SMTP_MAIL,
      to,
      subject,
      text,
    };

    await transporter.sendMail(mailOptions);
    console.log("✅ Email sent successfully to:", to);
  } catch (error) {
    console.error("❌ Error sending email:", error.message);
    throw new Error("Failed to send email");
  }
};

module.exports = { sendEmail };
