import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./features/auth/authSlice";
import campaignReducer from "./features/campaign/campaignSlice";

const store = configureStore({
  reducer: {
    auth: authReducer,
    campaign: campaignReducer,
  },
});

export default store;
