import React from "react";
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import Campaign from "../components/Campaign";
import Footer from "../components/Footer";

const Home = () => {
  return (
    <div className="overflow-x-hidden">
      <Navbar />
      <Hero />
      <Campaign />
      <Footer />
    </div>
  );
};

export default Home;
