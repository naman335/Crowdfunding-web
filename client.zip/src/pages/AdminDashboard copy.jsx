import React, { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";
import Modal from "../components/admin/Modal";
import { use } from "react";

const AdminDashboard = () => {
  const [selectedView, setSelectedView] = useState("campaigns");
  const [campaigns, setCampaigns] = useState([]);
  const [users, setUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState({ type: "", id: "" });
  const [categories, setCategories] = useState([]);

  // Fetch existing categories
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await axios.get(
          "http://localhost:5000/api/campaigns/categories"
        );
        setCategories(res.data);
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    };

    fetchCategories();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [campaignRes, userRes, messageRes] = await Promise.all([
          axios.get("http://localhost:5000/api/campaigns/admin", {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }),
          axios.get("http://localhost:5000/api/users/allusers", {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }),
          axios.get("http://localhost:5000/api/contact", {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }),
        ]);

        setCampaigns(campaignRes.data);
        console.log(userRes.data);
        setUsers(userRes.data);
        setMessages(messageRes.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const handleVerify = async (id) => {
    try {
      await axios.patch(
        `http://localhost:5000/api/admin/campaign/${id}/approve`,
        {},
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      setCampaigns(
        campaigns.map((c) =>
          c._id === id ? { ...c, isApproved: !c.isApproved } : c
        )
      );
    } catch (error) {
      console.error("Error updating campaign:", error);
    }
  };

  const handleDelete = async () => {
    try {
      await axios.delete(
        `http://localhost:5000/api/${deleteTarget.type}/${deleteTarget.id}`,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      if (deleteTarget.type === "campaigns") {
        setCampaigns(campaigns.filter((c) => c._id !== deleteTarget.id));
      } else {
        setUsers(users.filter((u) => u._id !== deleteTarget.id));
      }
      setShowDeleteModal(false);
    } catch (error) {
      console.error("Error deleting:", error);
    }
  };

  const handleMessageDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/contact/${id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setMessages(messages.filter((m) => m._id !== id));
    } catch (error) {
      console.error("Error deleting message:", error);
    }
  };

  const handleUpdateCampaign = async (updatedData) => {
    try {
      const res = await axios.patch(
        `http://localhost:5000/api/campaigns/update/${selectedCampaign._id}`,
        updatedData,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      );
      setCampaigns(
        campaigns.map((c) => (c._id === selectedCampaign._id ? res.data : c))
      );
      setShowUpdateModal(false);
    } catch (error) {
      console.error("Error updating campaign:", error);
    }
  };

  const renderTable = () => {
    switch (selectedView) {
      case "campaigns":
        return (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr>
                  <th className="py-2 px-4 border-b">Title</th>
                  <th className="py-2 px-4 border-b">Description</th>
                  <th className="py-2 px-4 border-b">Status</th>
                  <th className="py-2 px-4 border-b">Actions</th>
                </tr>
              </thead>
              <tbody>
                {campaigns.map((campaign) => (
                  <tr key={campaign._id}>
                    <td className="py-2 px-4 border-b">{campaign.title}</td>
                    <td className="py-2 px-4 border-b  ">
                      {/* only 40 words should be visible */}
                      {campaign.description.slice(0, 40) + "..."}
                      {/* {campaign.description} */}
                    </td>
                    <td className="py-2 px-4 border-b">
                      <span
                        className={`px-2 py-1 rounded ${
                          campaign.isApproved
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {campaign.isApproved ? "Approved" : "Pending"}
                      </span>
                    </td>
                    <td className="py-2 px-4 border-b space-x-2">
                      <button
                        onClick={() => handleVerify(campaign._id)}
                        className={`px-3 py-1 rounded ${
                          campaign.isApproved ? "bg-gray-500" : "bg-green-500"
                        } text-white`}
                      >
                        {campaign.isApproved ? "Disapprove" : "Approve"}
                      </button>
                      <button
                        onClick={() => {
                          setSelectedCampaign(campaign);
                          setShowUpdateModal(true);
                        }}
                        className="bg-blue-500 text-white px-3 py-1 rounded"
                      >
                        Update
                      </button>
                      <button
                        onClick={() => {
                          setDeleteTarget({
                            type: "campaigns",
                            id: campaign._id,
                          });
                          setShowDeleteModal(true);
                        }}
                        className="bg-red-500 text-white px-3 py-1 rounded"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      case "users":
        return (
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">Id</th>
                <th className="py-2 px-4 border-b">Name</th>
                <th className="py-2 px-4 border-b">Email</th>
                <th className="py-2 px-4 border-b">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user._id}>
                  <td className="py-2 px-4 border-b">{user._id}</td>
                  <td className="py-2 px-4 border-b  ">{user.name}</td>
                  <td className="py-2 px-4 border-b">{user.email}</td>
                  <td className="py-2 px-4 border-b space-x-2">
                    <button
                      onClick={() => {
                        setDeleteTarget({
                          type: "users",
                          id: user._id,
                        });
                        setShowDeleteModal(true);
                      }}
                      className="bg-red-500 text-white px-3 py-1 rounded"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        );

      case "messages":
        return (
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">Id</th>
                <th className="py-2 px-4 border-b">Name</th>
                <th className="py-2 px-4 border-b">Email</th>
                <th className="py-2 px-4 border-b">Message</th>
                <th className="py-2 px-4 border-b">Action</th>
              </tr>
            </thead>
            <tbody>
              {messages.map((message) => (
                <tr key={message._id}>
                  <td className="py-2 px-4 border-b">{message._id}</td>
                  <td className="py-2 px-4 border-b  ">{message.name}</td>
                  <td className="py-2 px-4 border-b">{message.email}</td>
                  <td>{message.message.slice(0, 40) + "..."}</td>
                  <td className="py-2 px-4 border-b space-x-2">
                    <button
                      onClick={() => handleMessageDelete(message._id)}
                      className="bg-red-500 text-white px-3 py-1 rounded"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="flex flex-col md:flex-row">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-white shadow-md p-4">
          <nav className="space-y-2">
            {["campaigns", "users", "messages", "settings"].map((view) => (
              <button
                key={view}
                onClick={() => setSelectedView(view)}
                className={`w-full text-left px-4 py-2 rounded hover:bg-gray-100 ${
                  selectedView === view ? "bg-blue-100 text-blue-600" : ""
                }`}
              >
                {view.charAt(0).toUpperCase() + view.slice(1)}
              </button>
            ))}
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          <h1 className="text-2xl font-bold mb-6">
            {selectedView.charAt(0).toUpperCase() + selectedView.slice(1)}{" "}
            Management
          </h1>
          {renderTable()}
        </div>
      </div>

      {/* Modals */}
      {showDeleteModal && (
        <Modal onClose={() => setShowDeleteModal(false)}>
          <h3 className="text-lg font-bold mb-4">Confirm Delete</h3>
          <p>Are you sure you want to delete this {deleteTarget.type}?</p>
          <div className="mt-4 flex justify-end space-x-2">
            <button
              onClick={() => setShowDeleteModal(false)}
              className="px-4 py-2 border rounded"
            >
              Cancel
            </button>
            <button
              onClick={handleDelete}
              className="px-4 py-2 bg-red-500 text-white rounded"
            >
              Delete
            </button>
          </div>
        </Modal>
      )}

      {showUpdateModal && (
        <Modal onClose={() => setShowUpdateModal(false)}>
          <h3 className="text-lg font-bold mb-4">Update Campaign</h3>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleUpdateCampaign({
                title: e.target.title.value,
                description: e.target.description.value,
                goal: e.target.goal.value,
                category: e.target.category.value,
              });
            }}
          >
            <input
              name="title"
              defaultValue={selectedCampaign.title}
              className="w-full p-2 border rounded mb-2"
            />
            <textarea
              name="description"
              defaultValue={selectedCampaign.description}
              className="w-full p-2 border rounded mb-4"
            />
            {/* goal  */}
            <input
              name="goal"
              defaultValue={selectedCampaign.goal}
              className="w-full p-2 border rounded mb-4"
            />

            {/* category */}
            <select
              name="category"
              defaultValue={selectedCampaign.category}
              className="w-full p-2 border rounded mb-4"
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>

            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setShowUpdateModal(false)}
                className="px-4 py-2 border rounded"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-500 text-white rounded"
              >
                Update
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default AdminDashboard;
