import React, { useState } from "react";
import axios from "axios";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Navbar from "../components/Navbar";
import Modal from "../components/admin/Modal";

const AdminDashboard = () => {
  const queryClient = useQueryClient();
  const [selectedView, setSelectedView] = useState("campaigns");
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState({ type: "", id: "" });

  const [previewImage, setPreviewImage] = useState(null); // Store selected image preview
  const [updating, setUpdating] = useState(false); // Track updating state

  const handleMilestoneEmail = async (campaignId) => {
    const message = prompt("Enter your message to send to backers:");
    if (!message) {
      alert("Message is required!");
      return;
    }

    try {
      await axios.post(
        `http://localhost:5000/api/campaigns/${campaignId}/milestone`,
        { message },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      alert("Milestone email sent successfully!");
    } catch (error) {
      console.error("Error sending milestone email:", error);
      alert("Failed to send email.");
    }
  };

  // Fetch data with React Query
  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const res = await axios.get(
        "http://localhost:5000/api/campaigns/categories"
      );
      return res.data;
    },
    staleTime: 1000 * 60 * 5, // Data is fresh for 5 minutes
    cacheTime: 1000 * 60 * 10, // Cache data for 10 minutes
  });

  const { data: campaigns = [] } = useQuery({
    queryKey: ["campaigns"],
    queryFn: async () => {
      const res = await axios.get("http://localhost:5000/api/campaigns/admin", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      return res.data;
    },
    staleTime: 1000 * 60 * 5, // Data is fresh for 5 minutes
    cacheTime: 1000 * 60 * 10, // Cache data for 10 minutes
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: async () => {
      const res = await axios.get("http://localhost:5000/api/users/allusers", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      return res.data;
    },
    staleTime: 1000 * 60 * 5, // Data is fresh for 5 minutes
    cacheTime: 1000 * 60 * 10, // Cache data for 10 minutes
  });

  const { data: messages = [] } = useQuery({
    queryKey: ["messages"],
    queryFn: async () => {
      const res = await axios.get("http://localhost:5000/api/contact", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      return res.data;
    },
    staleTime: 1000 * 60 * 5, // Data is fresh for 5 minutes
    cacheTime: 1000 * 60 * 10, // Cache data for 10 minutes
  });

  // Mutations
  const verifyMutation = useMutation({
    mutationFn: (id) =>
      axios.patch(
        `http://localhost:5000/api/admin/campaign/${id}/approve`,
        {},
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        }
      ),
    onSuccess: () => queryClient.invalidateQueries(["campaigns"]),
  });

  const deleteMutation = useMutation({
    mutationFn: ({ type, id }) =>
      axios.delete(`http://localhost:5000/api/${type}/${id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      }),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries(
        variables.type === "campaigns" ? ["campaigns"] : ["users"]
      );
      setShowDeleteModal(false);
    },
  });

  const deleteMessageMutation = useMutation({
    mutationFn: (id) =>
      axios.delete(`http://localhost:5000/api/contact/${id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      }),
    onSuccess: () => queryClient.invalidateQueries(["messages"]),
  });

  const updateCampaignMutation = useMutation({
    mutationFn: ({ id, formData }) =>
      axios.patch(
        `http://localhost:5000/api/campaigns/update/${id}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      ),
    onSuccess: () => {
      queryClient.invalidateQueries(["campaigns"]);
      setShowUpdateModal(false);
      setUpdating(false); // Reset button text
      setPreviewImage(null); // Reset preview after update
    },
    onError: () => {
      setUpdating(false); // Reset on error
    },
  });

  const renderTable = () => {
    switch (selectedView) {
      case "campaigns":
        return (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              {/* Campaigns table remains same */}
              <tbody>
                {campaigns.map((campaign) => (
                  <tr key={campaign._id}>
                    <td className="py-2 px-4 border-b">{campaign.title}</td>
                    <td className="py-2 px-4 border-b  ">
                      {/* only 40 words should be visible */}
                      {campaign.description.slice(0, 40) + "..."}
                      {/* {campaign.description} */}
                    </td>
                    <td className="py-2 px-4 border-b">
                      <span
                        className={`px-2 py-1 rounded ${
                          campaign.isApproved
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {campaign.isApproved ? "Approved" : "Pending"}
                      </span>
                    </td>
                    <td className="py-2 px-4 border-b space-x-2 flex items-center justify-center ">
                      <button
                        onClick={() => verifyMutation.mutate(campaign._id)}
                        className={`px-3 py-1 rounded ${
                          campaign.isApproved ? "bg-gray-200" : "bg-green-200"
                        } text-white`}
                        title={campaign.isApproved ? "Disapprove" : "Approve"}
                      >
                        {campaign.isApproved ? "⚠️" : "👀"}
                      </button>
                      <button
                        onClick={() => {
                          setSelectedCampaign(campaign);
                          setShowUpdateModal(true);
                        }}
                        title="Update"
                        className="bg-blue-200 text-white px-3 py-1 rounded"
                      >
                        ✏️
                      </button>
                      <button
                        onClick={() => {
                          setDeleteTarget({
                            type: "campaigns",
                            id: campaign._id,
                          });
                          setShowDeleteModal(true);
                        }}
                        title="Delete"
                        className="bg-red-200 text-white px-3 py-1 rounded"
                      >
                        ❌
                      </button>
                      <button
                        onClick={() => handleMilestoneEmail(campaign._id)}
                        className="bg-blue-200 text-white px-3 py-1 rounded"
                        title="Send Milestone Email"
                      >
                        📨
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      case "users":
        return (
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">Id</th>
                <th className="py-2 px-4 border-b">Name</th>
                <th className="py-2 px-4 border-b">Email</th>
                <th className="py-2 px-4 border-b">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user._id}>
                  <td className="py-2 px-4 border-b">{user._id}</td>
                  <td className="py-2 px-4 border-b  ">{user.name}</td>
                  <td className="py-2 px-4 border-b">{user.email}</td>
                  <td className="py-2 px-4 border-b space-x-2">
                    <button
                      onClick={() => {
                        setDeleteTarget({ type: "users", id: user._id });
                        setShowDeleteModal(true);
                      }}
                      className="bg-red-500 text-white px-3 py-1 rounded"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        );

      case "messages":
        return (
          <table className="min-w-full bg-white">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b">Id</th>
                <th className="py-2 px-4 border-b">Name</th>
                <th className="py-2 px-4 border-b">Email</th>
                <th className="py-2 px-4 border-b">Message</th>
                <th className="py-2 px-4 border-b">Action</th>
              </tr>
            </thead>
            <tbody>
              {messages.map((message) => (
                <tr key={message._id}>
                  <td className="py-2 px-4 border-b">{message._id}</td>
                  <td className="py-2 px-4 border-b  ">{message.name}</td>
                  <td className="py-2 px-4 border-b">{message.email}</td>
                  <td>{message.message.slice(0, 40) + "..."}</td>
                  <td className="py-2 px-4 border-b space-x-2">
                    <button
                      onClick={() => deleteMessageMutation.mutate(message._id)}
                      className="bg-red-500 text-white px-3 py-1 rounded"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="flex flex-col md:flex-row">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-white shadow-md p-4 h-auto md:h-screen ">
          <nav className="space-y-3">
            {["campaigns", "users", "messages"].map((view) => (
              <button
                key={view}
                onClick={() => setSelectedView(view)}
                className={`w-full text-left font-semibold px-4 py-2 rounded hover:bg-gray-100 ${
                  selectedView === view ? "bg-blue-100 text-blue-600" : ""
                }`}
              >
                {view.charAt(0).toUpperCase() + view.slice(1)}
              </button>
            ))}
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          <h1 className="text-2xl font-bold mb-6">
            {selectedView.charAt(0).toUpperCase() + selectedView.slice(1)}{" "}
            Management
          </h1>
          {renderTable()}
        </div>
      </div>

      {/* Modals */}
      {showDeleteModal && (
        <Modal onClose={() => setShowDeleteModal(false)}>
          <h3 className="text-lg font-bold mb-4">Confirm Delete</h3>
          <p>Are you sure you want to delete this {deleteTarget.type}?</p>
          <div className="mt-4 flex justify-end space-x-2">
            <button
              onClick={() => setShowDeleteModal(false)}
              className="px-4 py-2 border rounded"
            >
              Cancel
            </button>
            <button
              onClick={() => deleteMutation.mutate(deleteTarget)}
              className="px-4 py-2 bg-red-500 text-white rounded"
            >
              Delete
            </button>
          </div>
        </Modal>
      )}

      {showUpdateModal && (
        <Modal onClose={() => setShowUpdateModal(false)}>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setUpdating(true); // Start updating
              const formData = new FormData(e.target);
              updateCampaignMutation.mutate({
                id: selectedCampaign._id,
                formData,
              });
            }}
            encType="multipart/form-data"
          >
            <input
              name="title"
              defaultValue={selectedCampaign.title}
              className="w-full p-2 border rounded mb-2"
            />
            <textarea
              name="description"
              defaultValue={selectedCampaign.description}
              className="w-full p-2 border rounded mb-4"
            />
            <input
              name="goal"
              type="number"
              defaultValue={selectedCampaign.goal}
              className="w-full p-2 border rounded mb-4"
            />
            <select
              name="category"
              defaultValue={selectedCampaign.category}
              className="w-full p-2 border rounded mb-4"
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>

            {/* Image Update Input with Preview */}
            <input
              type="file"
              name="image"
              accept="image/*"
              className="w-full p-2 border rounded mb-4"
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) {
                  setPreviewImage(URL.createObjectURL(file)); // Generate preview URL
                }
              }}
            />

            {/* Show Preview of Selected Image */}
            {previewImage && (
              <div className="mb-4">
                <p className="text-sm">New Image Preview:</p>
                <img
                  src={previewImage}
                  alt="Preview"
                  className="w-full h-40 object-cover rounded border"
                />
              </div>
            )}

            {/* Show Current Image if No New Image is Selected */}
            {!previewImage && selectedCampaign.image && (
              <div className="mb-4">
                <p className="text-sm">Current Image:</p>
                <img
                  src={selectedCampaign.image}
                  alt="Current"
                  className="w-full h-40 object-cover rounded border"
                />
              </div>
            )}

            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setShowUpdateModal(false)}
                className="px-4 py-2 border rounded"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-500 text-white rounded"
              >
                {updating ? "Updating..." : "Update"} {/* Change Button Text */}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default AdminDashboard;
