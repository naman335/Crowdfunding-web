import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom"; // ✅ Import useNavigate
import PlaceholderImg from "../assets/placeholder.jpeg";

const fetchRecentCampaigns = async () => {
  const response = await fetch(
    "http://localhost:5000/api/campaigns/recent-campaigns"
  );
  if (!response.ok) {
    throw new Error("Network response was not ok");
  }
  return response.json();
};

const Campaign = () => {
  const navigate = useNavigate(); // ✅ Initialize navigate function

  const { data, isLoading, isError } = useQuery({
    queryKey: ["recentCampaigns"],
    queryFn: fetchRecentCampaigns,
  });

  console.log("recent campaign", data);
  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (isError) {
    return <div>Error fetching campaigns</div>;
  }

  return (
    <section className="py-16">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-blue-900 mb-8">
          Featured Campaigns
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {data.map((campaign) => (
            <div
              key={campaign._id}
              className="bg-white shadow-lg rounded-lg overflow-hidden cursor-pointer hover:-translate-y-1 transition duration-300 ease-in-out"
              onClick={() => navigate(`/campaign/${campaign._id}`)} // ✅ Add onClick event
            >
              <img
                src={campaign.image || PlaceholderImg}
                alt={campaign.title}
                className="w-full h-56 object-cover mb-2 rounded-md"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-900 mb-2">
                  {campaign.title}
                </h3>
                <p className="text-gray-700 mb-4">{campaign.description}</p>
                <div className="bg-gray-200 h-2 rounded-full mb-4">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{
                      width: `${
                        (campaign.raisedAmount / campaign.goal) * 100
                      }%`,
                    }}
                  ></div>
                </div>
                <div className="flex justify-between text-gray-700">
                  <span>₹{campaign.raisedAmount} raised</span>
                  <span>
                    {/* {(campaign.raisedAmount / campaign.goal) * 100}% funded */}
                    {Math.round((campaign.raisedAmount / campaign.goal) * 100)}%
                    funded
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Campaign;
