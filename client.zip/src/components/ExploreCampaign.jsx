import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import PlaceholderImg from "../assets/placeholder.jpeg";

const fetchCategories = async () => {
  const { data } = await axios.get(
    "http://localhost:5000/api/campaigns/categories"
  );
  return data;
};

const fetchCampaigns = async ({ queryKey }) => {
  const [, selectedCategory, minAmount, maxAmount] = queryKey;
  const queryParams = new URLSearchParams({
    ...(selectedCategory && { category: selectedCategory }),
    ...(minAmount && { minGoal: minAmount }),
    ...(maxAmount && { maxGoal: maxAmount }),
  });
  const { data } = await axios.get(
    `http://localhost:5000/api/campaigns?${queryParams}`
  );
  return data;
};

const ExploreCampaigns = () => {
  const [selectedCategory, setSelectedCategory] = useState("");
  const [minAmount, setMinAmount] = useState("");
  const [maxAmount, setMaxAmount] = useState("");
  const navigate = useNavigate();

  const { data: categories = [], isLoading: categoriesLoading } = useQuery({
    queryKey: ["categories"],
    queryFn: fetchCategories,
  });

  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery({
    queryKey: ["campaigns", selectedCategory, minAmount, maxAmount],
    queryFn: fetchCampaigns,
  });

  return (
    <div>
      <Navbar />
      <div className="flex flex-col md:flex-row p-8 gap-6">
        {/* Left Sidebar for Filters */}
        <div className="w-full md:w-1/4 bg-gray-100 p-4 rounded-lg shadow-md">
          <h2 className="text-xl font-bold mb-4">Filters</h2>

          {/* Category Filter */}
          <label className="block font-semibold mb-2">Category</label>
          <select
            className="w-full p-2 border rounded"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            {categoriesLoading ? (
              <option>Loading...</option>
            ) : (
              categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))
            )}
          </select>

          {/* Amount Filters */}
          <div className="mt-4">
            <label className="block font-semibold mb-2">
              Min Goal Amount (₹)
            </label>
            <input
              type="number"
              className="w-full p-2 border rounded"
              value={minAmount}
              onChange={(e) => setMinAmount(e.target.value)}
              placeholder="Enter min amount"
            />
          </div>
          <div className="mt-2">
            <label className="block font-semibold mb-2">
              Max Goal Amount (₹)
            </label>
            <input
              type="number"
              className="w-full p-2 border rounded"
              value={maxAmount}
              onChange={(e) => setMaxAmount(e.target.value)}
              placeholder="Enter max amount"
            />
          </div>
        </div>

        {/* Campaigns List */}
        <div className="w-full md:w-3/4">
          <h1 className="text-2xl font-bold mb-6">Explore Campaigns</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
            {campaignsLoading ? (
              <p>Loading campaigns...</p>
            ) : campaigns.length === 0 ? (
              <p>No campaigns found.</p>
            ) : (
              campaigns.map((campaign) => (
                <div
                  key={campaign._id}
                  className="bg-white p-4 rounded-lg shadow-md cursor-pointer"
                  onClick={() => navigate(`/campaign/${campaign._id}`)}
                >
                  {campaign.image === undefined || campaign.image === null ? (
                    <img
                      src={PlaceholderImg}
                      alt={campaign.title}
                      className="w-full h-56 object-cover mb-2 rounded-md "
                    />
                  ) : (
                    <img
                      src={campaign.image}
                      alt={campaign.title}
                      className="w-full h-56 object-cover mb-2 rounded-md"
                    />
                  )}
                  <span className="text-sm text-gray-500 mb-2">
                    {campaign.category}
                  </span>
                  <h2 className="text-xl font-bold text-blue-900 mb-2 line-clamp-2">
                    {campaign.title}
                  </h2>
                  <p className="text-gray-700 mb-2 line-clamp-2">
                    {campaign.description}
                  </p>
                  <div className="bg-gray-200 h-2 rounded-full mb-4">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{
                        width: `${
                          (campaign.raisedAmount / campaign.goal) * 100
                        }%`,
                      }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-gray-700">
                    <span>₹{campaign.raisedAmount} raised</span>
                    <span>
                      {Math.round(
                        (campaign.raisedAmount / campaign.goal) * 100
                      )}
                      % funded
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ExploreCampaigns;
