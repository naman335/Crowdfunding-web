import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "@tanstack/react-query";
import axios from "axios";
import Navbar from "./Navbar";
import Footer from "./Footer";
import DonateBg from "../assets/donate.svg";

const fetchCampaign = async (campaignId) => {
  const { data } = await axios.get(
    `http://localhost:5000/api/campaigns/${campaignId}`
  );
  return data;
};

const PaymentPage = () => {
  const { campaignId } = useParams();
  const navigate = useNavigate();
  const [amount, setAmount] = useState("");

  // Fetch campaign details
  const {
    data: campaign,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["campaign", campaignId],
    queryFn: () => fetchCampaign(campaignId),
  });

  // Mutation for handling payment
  const paymentMutation = useMutation({
    mutationFn: async () => {
      const res = await axios.post(
        `http://localhost:5000/api/campaigns/${campaignId}/fund`,
        { amount },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      return res.data;
    },
    onSuccess: (data) => {
      loadRazorpay(data);
    },
    onError: () => {
      alert("Payment initiation failed.");
    },
  });

  const loadRazorpay = ({ orderId, amount: finalAmount, currency, key }) => {
    const razorpayScript = document.createElement("script");
    razorpayScript.src = "https://checkout.razorpay.com/v1/checkout.js";
    razorpayScript.async = true;
    document.body.appendChild(razorpayScript);

    razorpayScript.onload = () => {
      const options = {
        key,
        amount: finalAmount,
        currency,
        name: "EmpowerFund",
        description: "Support the campaign",
        order_id: orderId,
        handler: function (response) {
          axios
            .post(
              `http://localhost:5000/api/campaigns/${campaignId}/verify-payment`,
              {
                paymentId: response.razorpay_payment_id,
                amount: finalAmount / 100,
              },
              {
                headers: {
                  Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
              }
            )
            .then(() => {
              navigate(`/payment-success/${campaignId}`);
            })
            .catch(() => {
              navigate(`/payment-error/${campaignId}`);
            });
        },
        prefill: { name: "User Name", email: "user@example.com" },
        theme: { color: "#3399cc" },
        modal: {
          escape: true,
          ondismiss: function () {
            console.log("User closed the payment window.");
          },
        },
      };
      const paymentInstance = new window.Razorpay(options);
      paymentInstance.open();
    };
  };

  if (isLoading) return <p>Loading campaign details...</p>;
  if (error) return <p className="text-red-500">Error loading campaign.</p>;

  return (
    <div>
      <Navbar />
      <div
        style={{ backgroundImage: `url(${DonateBg})` }}
        className="bg-cover bg-center min-h-[90vh] flex flex-col items-center justify-center bg-gray-100"
      >
        <div className="bg-white p-8 rounded-lg flex flex-col items-center shadow-md">
          <h1 className="text-2xl font-bold mb-4">
            {campaign?.title || "Support the Campaign"}
          </h1>
          <input
            type="number"
            placeholder="Enter Amount (₹)"
            className="w-64 p-2 border rounded-lg text-center mb-4"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            min="1"
          />
          {paymentMutation.isError && (
            <p className="text-red-500">Payment failed.</p>
          )}

          <button
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            onClick={() => paymentMutation.mutate()}
            disabled={paymentMutation.isLoading}
          >
            {paymentMutation.isLoading ? "Processing..." : "Donate Now"}
          </button>

          <button
            className="mt-6 px-6 text-gray-500 hover:text-gray-700 text-sm"
            onClick={() => navigate(`/campaign/${campaignId}`)}
          >
            Go Back to Campaign
          </button>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default PaymentPage;
