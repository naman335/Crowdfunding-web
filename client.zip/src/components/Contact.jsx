import React, { useState } from "react";
import Navbar from "./Navbar";
import { useMutation } from "@tanstack/react-query";
import axios from "axios";
import Footer from "./Footer";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const mutation = useMutation({
    mutationFn: async (data) => {
      return axios.post("http://localhost:5000/api/contact", data, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
    },
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await mutation.mutateAsync(formData);
      setFormData({ name: "", email: "", message: "" });
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  return (
    <div>
      <Navbar />
      <div className="max-w-2xl mx-auto p-6">
        <h1 className="text-3xl font-bold text-center mb-6">Contact Us</h1>
        <p className="text-gray-700 text-lg text-center mb-6">
          Have a question or need help? Reach out to us, and we’ll be happy to
          assist you.
        </p>

        {mutation.isSuccess && (
          <p className="text-center text-green-600 mb-4">
            Message sent successfully! We'll get back to you soon.
          </p>
        )}
        {mutation.isError && (
          <p className="text-center text-red-600 mb-4">
            Something went wrong. Please try again.
          </p>
        )}

        <form
          onSubmit={handleSubmit}
          className="bg-gray-100 p-6 rounded-lg shadow-md"
        >
          <label className="block font-semibold mb-2">Name</label>
          <input
            type="text"
            name="name"
            className="w-full p-2 border rounded mb-4"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleChange}
            required
          />

          <label className="block font-semibold mb-2">Email</label>
          <input
            type="email"
            name="email"
            className="w-full p-2 border rounded mb-4"
            placeholder="Your Email"
            value={formData.email}
            onChange={handleChange}
            required
          />

          <label className="block font-semibold mb-2">Message</label>
          <textarea
            name="message"
            className="w-full p-2 border rounded mb-4"
            placeholder="Your Message"
            value={formData.message}
            onChange={handleChange}
            rows="4"
            required
          ></textarea>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            disabled={mutation.isPending}
          >
            {mutation.isPending ? "Sending..." : "Send Message"}
          </button>
        </form>

        <div className="text-center mt-6">
          <h2 className="text-xl font-bold mb-2">📍 Visit Us</h2>
          <p className="text-gray-700">
            Empower Fund HQ, 123 Innovation Street, New Delhi, India
          </p>
          <p className="text-gray-700">
            📧 support@empowerfund.com | ☎️ +91 98765 43210
          </p>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Contact;
