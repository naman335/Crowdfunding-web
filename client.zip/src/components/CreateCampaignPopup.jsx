import React, { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import axios from "axios";

const fetchCategories = async () => {
  const res = await axios.get("http://localhost:5000/api/campaigns/categories");
  return res.data;
};

const createCampaign = async (data) => {
  return axios.post("http://localhost:5000/api/campaigns/create", data, {
    headers: {
      "Content-Type": "multipart/form-data",
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
  });
};

const CreateCampaignPopup = ({ onClose }) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [goal, setGoal] = useState("");
  const [category, setCategory] = useState("");
  const [newCategory, setNewCategory] = useState("");
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);

  const {
    data: categories = [],
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["categories"],
    queryFn: fetchCategories,
  });

  const mutation = useMutation({
    mutationFn: createCampaign,
    onSuccess: () => {
      alert("Campaign created successfully!");
      onClose();
    },
    onError: (error) => {
      console.error("Error creating campaign:", error);
      alert("Failed to create campaign. Please try again.");
    },
  });

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("title", title);
    formData.append("description", description);
    formData.append("goal", goal);
    formData.append("category", category === "new" ? newCategory : category);
    if (image) {
      formData.append("image", image);
    }

    mutation.mutate(formData);
  };

  return (
    <div className="fixed inset-[-17px] w-full bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-lg shadow-md w-96">
        <h2 className="text-xl font-bold mb-4">Create Campaign</h2>
        {isLoading && <p>Loading categories...</p>}
        {isError && <p className="text-red-600">Error loading categories</p>}
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <input
            type="text"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2 mb-4 border rounded"
            required
          />
          <textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-2 mb-4 border rounded"
            required
          />
          <input
            type="number"
            placeholder="Goal (₹)"
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            className="w-full p-2 mb-4 border rounded"
            required
          />

          {/* Category Selection */}
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full p-2 mb-4 border rounded"
            required
          >
            <option value="">Select Category</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
            <option value="new">Create New Category</option>
          </select>

          {/* Show input field if "Create New Category" is selected */}
          {category === "new" && (
            <input
              type="text"
              placeholder="Enter New Category"
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
              className="w-full p-2 mb-4 border rounded"
              required
            />
          )}

          {/* Image Upload & Preview */}
          <input
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            className="w-full p-2 mb-2 border rounded"
            required
          />
          {preview && (
            <img
              src={preview}
              alt="Selected Preview"
              className="w-full h-40 object-cover mb-4 rounded border"
            />
          )}

          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="bg-gray-500 text-white px-4 py-2 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded"
              disabled={mutation.isPending}
            >
              {mutation.isPending ? "Creating..." : "Create"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateCampaignPopup;
