import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { useNavigate, useParams } from "react-router-dom";

const PaymentError = () => {
  const navigate = useNavigate();
  const { campaignId } = useParams();

  return (
    <div>
      <Navbar />
      <div className="flex flex-col gap-4 items-center justify-center h-[90vh] bg-red-100">
        <h1 className="text-2xl font-bold text-red-700">Payment Failed!</h1>
        <p className="text-gray-700">Something went wrong. Please try again.</p>
        <button
          className="mt-4 px-6 py-2 bg-gray-500 text-white rounded-lg"
          onClick={() => navigate(`/campaign/${campaignId}`)}
        >
          Try Once More
        </button>
      </div>
      <Footer />
    </div>
  );
};

export default PaymentError;
