import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import ThanksImg from "../assets/thanks.jpg";

const PaymentSuccess = () => {
  const navigate = useNavigate();
  const { campaignId } = useParams(); // Get campaign ID from URL params
  const [countdown, setCountdown] = useState(10); // Countdown starts from 3

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000); // Decrease the countdown every second

    if (countdown === 0) {
      navigate(`/campaign/${campaignId}`); // Redirect when countdown reaches 0
    }

    return () => clearInterval(timer); // Cleanup on unmount
  }, [countdown, navigate, campaignId]);

  return (
    <div>
      <Navbar />
      <div className="flex flex-col items-center justify-center h-[80vh]">
        <img src={ThanksImg} alt="" className="w-72" />
        <h1 className="text-2xl font-bold text-green-700">
          Payment Successful!
        </h1>
        <p className="text-gray-700">Thank you for your contribution.</p>
        <p className="text-gray-500 mt-2 text-sm">
          Redirecting in <span className="font-bold">{countdown}</span>{" "}
          seconds...
        </p>
        <button
          className="mt-4 px-6 py-2 bg-blue-500 text-white rounded-lg"
          onClick={() => navigate(`/campaign/${campaignId}`)}
        >
          Go to Campaign Now
        </button>
      </div>
      <Footer />
    </div>
  );
};

export default PaymentSuccess;
