import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";

const About = () => {
  return (
    <div>
      <Navbar />
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold text-center mb-6">
          About Empower Fund
        </h1>
        <p className="text-gray-700 text-lg text-center mb-6">
          Empower Fund is a crowdfunding platform dedicated to supporting social
          causes, entrepreneurs, and innovators. Our mission is to connect
          passionate individuals with the resources they need to make a real
          impact.
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-4 bg-gray-100 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-2">🌍 Our Mission</h2>
            <p className="text-gray-700">
              We believe in the power of community-driven funding. Our platform
              enables people to raise funds for projects that matter, from
              education and healthcare to technology and sustainability.
            </p>
          </div>

          <div className="p-4 bg-gray-100 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-2">💡 How It Works</h2>
            <p className="text-gray-700">
              1️⃣ Create a campaign. 2️⃣ Share your story. 3️⃣ Get funded by
              supporters worldwide.
            </p>
          </div>
        </div>

        <div className="text-center mt-8">
          <h2 className="text-xl font-bold mb-2">
            Join Us in Empowering Change!
          </h2>
          <p className="text-gray-700">
            Start your campaign today and make a difference.
          </p>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default About;
