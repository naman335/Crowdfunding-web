import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import Navbar from "./Navbar";
import Footer from "./Footer";
import PlaceholderImg from "../assets/placeholder.jpeg";

const fetchCampaignDetails = async (id) => {
  const res = await axios.get(`http://localhost:5000/api/campaigns/${id}`);
  return res.data;
};

const CampaignDetails = () => {
  const { id } = useParams(); // Get campaign ID from URL
  const navigate = useNavigate();

  // Use React Query to fetch campaign details
  const {
    data: campaign,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["campaignDetails", id],
    queryFn: () => fetchCampaignDetails(id),
  });

  const handleFundCampaign = () => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login");
    } else {
      navigate(`/payment/${id}`);
    }
  };

  if (isLoading) {
    return <p className="text-center mt-10">Loading campaign details...</p>;
  }

  if (isError || !campaign) {
    return (
      <p className="text-center mt-10 text-red-500">Campaign not found!</p>
    );
  }

  return (
    <div>
      <Navbar />
      <div className="container mx-auto p-6 flex flex-col md:flex-row gap-6">
        {/* Left Side: Campaign Details */}
        <div className="w-full md:w-2/3 bg-white p-6 rounded-lg shadow-md">
          {campaign.image === undefined || campaign.image === null ? (
            <img
              src={PlaceholderImg}
              alt={campaign.title}
              className="w-full h-96 object-cover mb-2 rounded-md "
            />
          ) : (
            <img
              src={campaign.image}
              alt={campaign.title}
              className="w-full h-96 object-cover mb-4 rounded-md"
            />
          )}
          <h1 className="text-3xl font-bold mb-4">{campaign.title}</h1>
          <p className="text-gray-600 mb-2">
            <strong>Category:</strong> {campaign.category}
          </p>
          <p className="text-gray-700 mb-4">{campaign.description}</p>

          {/* Supporters Section */}
          <h2 className="text-xl font-bold mt-6 mb-2">Supporters</h2>
          {campaign.backers.length > 0 ? (
            <ul className="border p-4 rounded-lg bg-gray-100">
              {campaign.backers.map((backer, index) => (
                <li key={index} className="mb-2">
                  <span className="font-semibold">Name:</span>{" "}
                  {backer.user?.name || "Anonymous"} -
                  <span className="text-green-600 font-semibold">
                    {" "}
                    ₹{backer.amount}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No supporters yet. Be the first!</p>
          )}
        </div>

        {/* Right Side: Funding Section */}
        <div className="w-full md:w-1/3 sticky top-6 h-auto md:h-screen">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold mb-4">
              Funding Progress ❤️ {campaign.backers.length}
            </h2>
            <p className="text-gray-600 mb-2">
              <strong>Goal:</strong> ₹{campaign.goal}
            </p>
            <p className="text-gray-600 mb-2">
              <strong>Raised:</strong> ₹{campaign.raisedAmount}
            </p>
            <div className="w-full bg-gray-200 h-3 rounded-full mb-4">
              <div
                className="bg-blue-600 h-3 rounded-full"
                style={{
                  width: `${(campaign.raisedAmount / campaign.goal) * 100}%`,
                }}
              ></div>
            </div>
            <p className="text-gray-700 mb-4">
              {Math.round((campaign.raisedAmount / campaign.goal) * 100)}%
              funded
            </p>
            <button
              onClick={handleFundCampaign}
              className="w-full bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
            >
              Fund This Campaign
            </button>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default CampaignDetails;
