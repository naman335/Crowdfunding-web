import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import CreateCampaignPopup from "./CreateCampaignPopup";

const Hero = () => {
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();

  const handleClick = () => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login"); // Redirect to login if not logged in
    } else {
      setShowPopup(true); // Show popup if logged in
    }
  };
  return (
    <section className="bg-blue-50 py-20">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <h1 className="text-5xl font-bold text-blue-900 mb-6 max-w-3xl mx-auto">
          Fund Your Dreams, Empower Your Future
        </h1>
        <p className="text-xl text-gray-700 mb-8">
          Join thousands of creators and backers to bring innovative ideas to
          life.
        </p>
        <div className="space-x-4">
          <button
            onClick={handleClick}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
          >
            Start a Campaign
          </button>
          {showPopup && (
            <CreateCampaignPopup onClose={() => setShowPopup(false)} />
          )}
          <Link
            to="/campaigns"
            className="bg-green-600 text-white px-6 py-4 rounded-lg hover:bg-green-700"
          >
            Explore Campaigns
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Hero;
