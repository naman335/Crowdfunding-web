import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import AdminDashboard from "./pages/AdminDashboard";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ExploreCampaigns from "./components/ExploreCampaign";
import PaymentPage from "./components/PaymentPage";
import PaymentSuccess from "./components/PaymentSuccess";
import PaymentError from "./components/PaymentError";
import About from "./components/About";
import Contact from "./components/Contact";
import CampaignDetails from "./components/CampaignDetails";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/campaigns" element={<ExploreCampaigns />} />
        <Route path="/campaign/:id" element={<CampaignDetails />} />
        <Route path="dashboard" element={<AdminDashboard />}></Route>
        <Route path="/payment/:campaignId" element={<PaymentPage />} />
        <Route
          path="/payment-success/:campaignId"
          element={<PaymentSuccess />}
        />
        <Route path="/payment-error/:campaignId" element={<PaymentError />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
