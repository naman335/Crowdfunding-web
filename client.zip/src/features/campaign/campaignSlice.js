import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import campaignService from "./campaignService";

const initialState = {
  campaigns: [],
  campaignDetails: null,
  isLoading: false,
  isError: false,
  isSuccess: false,
  message: "",
};

// Fetch all campaigns
export const fetchCampaigns = createAsyncThunk(
  "campaigns/fetchAll",
  async (_, thunkAPI) => {
    try {
      return await campaignService.getAllCampaigns();
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data.message);
    }
  }
);

// Fetch campaign details
export const fetchCampaignDetails = createAsyncThunk(
  "campaigns/fetchDetails",
  async (id, thunkAPI) => {
    try {
      return await campaignService.getCampaignById(id);
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data.message);
    }
  }
);

// Create a new campaign
export const createCampaign = createAsyncThunk(
  "campaigns/create",
  async (campaignData, thunkAPI) => {
    try {
      const token = thunkAPI.getState().auth.user.token; // Assuming the token is stored in auth slice
      return await campaignService.createCampaign(campaignData, token);
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data.message);
    }
  }
);

const campaignSlice = createSlice({
  name: "campaigns",
  initialState,
  reducers: {
    reset: (state) => initialState,
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCampaigns.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchCampaigns.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.campaigns = action.payload;
      })
      .addCase(fetchCampaigns.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      })
      .addCase(fetchCampaignDetails.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchCampaignDetails.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.campaignDetails = action.payload;
      })
      .addCase(fetchCampaignDetails.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      })
      .addCase(createCampaign.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(createCampaign.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.campaigns.push(action.payload);
      })
      .addCase(createCampaign.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      });
  },
});

export const { reset } = campaignSlice.actions;
export default campaignSlice.reducer;
