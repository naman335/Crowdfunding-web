import axios from "axios";

const API_URL = "/api/campaigns/"; // Adjust base URL as per your backend setup

// Get all campaigns
const getAllCampaigns = async () => {
  const response = await axios.get(API_URL);
  return response.data;
};

// Get campaign by ID
const getCampaignById = async (id) => {
  const response = await axios.get(`${API_URL}${id}`);
  return response.data;
};

// Create a new campaign
const createCampaign = async (campaignData, token) => {
  const config = {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  const response = await axios.post(API_URL, campaignData, config);
  return response.data;
};

const campaignService = {
  getAllCampaigns,
  getCampaignById,
  createCampaign,
};

export default campaignService;
